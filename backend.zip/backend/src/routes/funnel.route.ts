import { Router } from "express";
import { createFunnel } from "../controllers/funnel.controller";

const router = Router();

router.post("/funnel", createFunnel);

export default router;
